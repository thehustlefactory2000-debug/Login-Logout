import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';

const Navbar = () => {
  const [userRole, setUserRole] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', session.user.id)
          .single();
        if (error) {
          console.error('Error fetching profile:', error);
        } else {
          setUserRole(profile.role);
        }
      }
    };

    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        supabase
          .from('profiles')
          .select('role')
          .eq('id', session.user.id)
          .single()
          .then(({ data: profile, error }) => {
            if (error) {
              console.error('Error fetching profile on auth change:', error);
            } else {
              setUserRole(profile.role);
            }
          });
      } else {
        setUserRole(null);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUserRole(null);
    navigate('/signin');
  };

  return (
    <nav className="bg-gradient-to-r from-indigo-600 to-purple-800 p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-white text-3xl font-bold">Salon PWA</Link>

        <div className="hidden md:flex space-x-4">
          {userRole === 'admin' && (
            <>
              <Link to="/admin" className="text-indigo-100 hover:text-indigo-50">Admin Dashboard</Link>
              <Link to="/admin/services" className="text-indigo-100 hover:text-indigo-50">Manage Services</Link>
              <Link to="/admin/customers" className="text-indigo-100 hover:text-indigo-50">Manage Customers</Link>
              <Link to="/admin/inventory" className="text-indigo-100 hover:text-indigo-50">Manage Inventory</Link>
              <Link to="/admin/bills" className="text-indigo-100 hover:text-indigo-50">Manage Bills</Link>
            </>
          )}
          {userRole === 'staff' && (
            <>
              <Link to="/staff" className="text-indigo-100 hover:text-indigo-50">Staff Dashboard</Link>
              <Link to="/staff/bills" className="text-indigo-100 hover:text-indigo-50">My Bills</Link>
            </>
          )}
          {userRole && (
            <button onClick={handleLogout} className="text-indigo-100 hover:text-indigo-50">Logout</button>
          )}
          {!userRole && (
            <Link to="/signin" className="text-indigo-100 hover:text-indigo-50">Sign In</Link>
          )}
        </div>

        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)} className="text-white focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-indigo-700 mt-2 space-y-2 p-2 rounded-md">
          {userRole === 'admin' && (
            <>
              <Link to="/admin" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Admin Dashboard</Link>
              <Link to="/admin/services" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Manage Services</Link>
              <Link to="/admin/customers" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Manage Customers</Link>
              <Link to="/admin/inventory" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Manage Inventory</Link>
              <Link to="/admin/bills" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Manage Bills</Link>
            </>
          )}
          {userRole === 'staff' && (
            <>
              <Link to="/staff" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Staff Dashboard</Link>
              <Link to="/staff/bills" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>My Bills</Link>
            </>
          )}
          {userRole && (
            <button onClick={() => { handleLogout(); setIsOpen(false); }} className="block text-indigo-100 hover:text-indigo-50 w-full text-left">Logout</button>
          )}
          {!userRole && (
            <Link to="/signin" className="block text-indigo-100 hover:text-indigo-50" onClick={() => setIsOpen(false)}>Sign In</Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;