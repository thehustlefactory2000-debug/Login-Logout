CREATE TABLE bills (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id UUID REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  staff_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  bill_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  total_amount NUMERIC(10, 2) NOT NULL,
  payment_mode TEXT NOT NULL, -- 'Online' or 'Offline'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE bill_services (
  bill_id UUID REFERENCES bills(id) ON DELETE CASCADE NOT NULL,
  service_id UUID REFERENCES services(id) ON DELETE CASCADE NOT NULL,
  quantity INTEGER DEFAULT 1,
  price NUMERIC(10, 2) NOT NULL,
  PRIMARY KEY (bill_id, service_id)
);

CREATE TABLE bill_products (
  bill_id UUID REFERENCES bills(id) ON DELETE CASCADE NOT NULL,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  quantity INTEGER NOT NULL,
  price NUMERIC(10, 2) NOT NULL,
  PRIMARY KEY (bill_id, product_id)
);

ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE bill_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE bill_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view bills" ON bills FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY "Admin users can manage bills" ON bills FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')) WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Authenticated users can view bill services" ON bill_services FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY "Admin users can manage bill services" ON bill_services FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')) WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Authenticated users can view bill products" ON bill_products FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY "Admin users can manage bill products" ON bill_products FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')) WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Staff can create and update their own bills
CREATE POLICY "Staff can create their own bills" ON bills FOR INSERT TO authenticated WITH CHECK (staff_id = auth.uid());
CREATE POLICY "Staff can update their own bills" ON bills FOR UPDATE TO authenticated USING (staff_id = auth.uid());

-- Staff can manage services and products within their own bills
CREATE POLICY "Staff can manage bill services for their own bills" ON bill_services FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM bills WHERE id = bill_id AND staff_id = auth.uid()));
CREATE POLICY "Staff can manage bill products for their own bills" ON bill_products FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM bills WHERE id = bill_id AND staff_id = auth.uid()));