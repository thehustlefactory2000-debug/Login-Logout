create table public.profiles (
  id uuid not null,
  email text null,
  role text null,
  name text null,
  created_at timestamp with time zone null default now(),
  constraint profiles_pkey primary key (id),
  constraint profiles_id_fkey foreign KEY (id) references auth.users (id) on delete CASCADE,
  constraint profiles_role_check check (
    (role = any (array['admin'::text, 'staff'::text]))
  )
) TABLESPACE pg_default;