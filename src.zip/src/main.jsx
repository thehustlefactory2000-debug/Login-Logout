import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import App from './App.jsx';
import SignIn from './pages/SignIn.jsx';
import SignUp from './pages/SignUp.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import InventoryManagement from './pages/InventoryManagement.jsx';
import StaffDashboard from './pages/StaffDashboard.jsx';
import ManageServices from './pages/ManageServices.jsx';
import ManageCustomers from './pages/ManageCustomers.jsx';
import ManageInventory from './pages/ManageInventory.jsx';
import ManageBills from './pages/ManageBills.jsx';
import StaffBills from './pages/StaffBills.jsx';
import ProtectedRoute from './components/ProtectedRoute';


import './index.css';
// Register service worker
// if ('serviceWorker' in navigator) {
//   window.addEventListener('load', () => {
//     navigator.serviceWorker.register('/service-worker.js')
//       .then(registration => {
//         console.log('SW registered: ', registration);
//       })
//       .catch(registrationError => {
//         console.log('SW registration failed: ', registrationError);
//       });
//   });
// }

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route path="/" element={<App />}>
          <Route index element={<SignIn />} /> {/* Default route for App */}
          <Route path="signin" element={<SignIn />} />
          <Route path="signup" element={<SignUp />} />
          <Route path="admin" element={<ProtectedRoute requiredRole="admin"><AdminDashboard /></ProtectedRoute>} />
          <Route path="admin/services" element={<ProtectedRoute requiredRole="admin"><ManageServices /></ProtectedRoute>} />
          <Route path="admin/customers" element={<ProtectedRoute requiredRole="admin"><ManageCustomers /></ProtectedRoute>} />
          <Route path="admin/inventory" element={<ProtectedRoute requiredRole="admin"><ManageInventory /></ProtectedRoute>} />
          <Route path="admin/bills" element={<ProtectedRoute requiredRole="admin"><ManageBills /></ProtectedRoute>} />
          <Route path="inventory" element={<ProtectedRoute requiredRole="admin"><InventoryManagement /></ProtectedRoute>} />
          <Route path="staff" element={<ProtectedRoute requiredRole="staff"><StaffDashboard /></ProtectedRoute>} />
          <Route path="staff/bills" element={<ProtectedRoute requiredRole="staff"><StaffBills /></ProtectedRoute>} />
        </Route>
      </Routes>
    </Router>
  </React.StrictMode>,
);