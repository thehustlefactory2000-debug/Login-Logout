import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';

const AdminDashboard = () => {
  const [adminData, setAdminData] = useState(null);
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const user = await supabase.auth.getUser();
      if (!user.data) {
        navigate('/signin'); // Redirect to login if not authenticated
      } else {
        fetchAdminData();
        fetchInventory();
      }
    };

    checkAuth();
  }, []);

  const fetchAdminData = async () => {
    try {
      const { data, error } = await supabase.from('admin_data').select('*');
      if (error) throw error;
      setAdminData(data);
    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchInventory = async () => {
    try {
      const { data, error } = await supabase.from('inventory').select('*');
      if (error) throw error;
      setInventory(data);
    } catch (error) {
      console.error('Error fetching inventory:', error);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/signin');
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-100"><p className="text-gray-700">Loading...</p></div>;
  }

  return (
    <div className="min-h-screen flex flex-col items-center bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <div className="bg-background-light p-8 rounded-xl shadow-2xl w-full max-w-4xl mt-8">
        <h2 className="text-3xl font-extrabold text-primary-accent mb-6 text-center">Admin Dashboard</h2>
        <div className="space-y-4">
          {adminData ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <p className="text-text-secondary">Total Users: <span className="font-semibold text-text-primary">{adminData[0]?.total_users}</span></p>
              <p className="text-text-secondary">Total Inventory Items: <span className="font-semibold text-text-primary">{adminData[0]?.total_inventory}</span></p>
            </div>
          ) : (
            <p className="text-text-secondary text-center">No data available</p>
          )}

          <h3 className="text-2xl font-semibold text-primary-accent mt-6 mb-4">Inventory</h3>
          {inventory.length > 0 ? (
            <ul className="list-disc list-inside space-y-2">
              {inventory.map((item) => (
                <li key={item.id} className="text-text-secondary">{item.name}</li>
              ))}
            </ul>
          ) : (
            <p className="text-text-secondary text-center">No inventory items available</p>
          )}

          <button onClick={handleLogout} className="mt-6 bg-primary-accent hover:bg-primary-dark text-white px-5 py-2 rounded-lg shadow-md transition duration-300 ease-in-out w-full">
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;