import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

const InventoryManagement = () => {
  const [inventory, setInventory] = useState([]);
  const [newItem, setNewItem] = useState('');

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    const { data, error } = await supabase.from('inventory').select('*');
    if (error) console.error(error);
    else setInventory(data);
  };

  const addItem = async () => {
    if (!newItem) return;
    const { error } = await supabase.from('inventory').insert([{ name: newItem }]);
    if (error) console.error(error);
    else {
      setNewItem('');
      fetchInventory();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <div className="bg-background-light p-8 rounded-xl shadow-2xl w-full max-w-md mt-8 mx-auto">
        <h2 className="text-3xl font-extrabold text-primary-accent mb-6 text-center">Inventory Management</h2>
        <div className="space-y-4">
          <input
            type="text"
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            placeholder="Add new item"
            className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
          />
          <button onClick={addItem} className="bg-primary-accent hover:bg-primary-dark text-white px-5 py-2 rounded-lg shadow-md transition duration-300 ease-in-out w-full">
            Add Item
          </button>
          <ul className="list-disc list-inside space-y-2 text-text-primary">
            {inventory.map((item) => (
              <li key={item.id} className="flex items-center justify-between bg-gray-50 p-2 rounded-lg shadow-sm">
                <span>{item.name}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default InventoryManagement;