import React, { useState, useEffect } from 'react';
import { createBill, getBills, updateBill, deleteBill } from '../lib/billApi';
import { getCustomers } from '../lib/customerApi';
import { getServices } from '../lib/serviceApi';
import { getProducts } from '../lib/productApi';
import { supabase } from '../lib/supabaseClient';

const ManageBills = () => {
  const [bills, setBills] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [services, setServices] = useState([]);
  const [products, setProducts] = useState([]);
  const [staff, setStaff] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    customer_id: '',
    staff_id: '',
    payment_mode: 'Offline',
    selectedServices: [],
    selectedProducts: [],
    total_amount: 0,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [billsData, customersData, servicesData, productsData] = await Promise.all([
        getBills(),
        getCustomers(),
        getServices(),
        getProducts(),
      ]);
      setBills(billsData);
      setCustomers(customersData);
      setServices(servicesData);
      setProducts(productsData);

      const { data: staffData, error } = await supabase
        .from('profiles')
        .select('id, full_name')
        .eq('role', 'staff');
      if (error) throw error;
      setStaff(staffData);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const calculateTotal = () => {
    let total = 0;
    formData.selectedServices.forEach(service => {
      const s = services.find(s => s.id === service.id);
      if (s) total += s.cost * (service.quantity || 1);
    });
    formData.selectedProducts.forEach(product => {
      const p = products.find(p => p.id === product.id);
      if (p) total += p.cost_price * product.quantity;
    });
    setFormData(prev => ({ ...prev, total_amount: total }));
  };

  useEffect(() => {
    calculateTotal();
  }, [formData.selectedServices, formData.selectedProducts, services, products]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleServiceChange = (serviceId, quantity) => {
    setFormData(prev => {
      const existingServiceIndex = prev.selectedServices.findIndex(s => s.id === serviceId);
      if (existingServiceIndex > -1) {
        const updatedServices = [...prev.selectedServices];
        updatedServices[existingServiceIndex] = { ...updatedServices[existingServiceIndex], quantity: parseInt(quantity) };
        return { ...prev, selectedServices: updatedServices };
      } else {
        const service = services.find(s => s.id === serviceId);
        return { ...prev, selectedServices: [...prev.selectedServices, { id: serviceId, quantity: parseInt(quantity), cost: service.cost }] };
      }
    });
  };

  const handleProductChange = (productId, quantity) => {
    setFormData(prev => {
      const existingProductIndex = prev.selectedProducts.findIndex(p => p.id === productId);
      if (existingProductIndex > -1) {
        const updatedProducts = [...prev.selectedProducts];
        updatedProducts[existingProductIndex] = { ...updatedProducts[existingProductIndex], quantity: parseInt(quantity) };
        return { ...prev, selectedProducts: updatedProducts };
      } else {
        const product = products.find(p => p.id === productId);
        return { ...prev, selectedProducts: [...prev.selectedProducts, { id: productId, quantity: parseInt(quantity), cost_price: product.cost_price }] };
      }
    });
  };

  const handleRemoveService = (serviceId) => {
    setFormData(prev => ({
      ...prev,
      selectedServices: prev.selectedServices.filter(s => s.id !== serviceId),
    }));
  };

  const handleRemoveProduct = (productId) => {
    setFormData(prev => ({
      ...prev,
      selectedProducts: prev.selectedProducts.filter(p => p.id !== productId),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const billToSubmit = {
        customer_id: formData.customer_id,
        staff_id: formData.staff_id,
        payment_mode: formData.payment_mode,
        total_amount: formData.total_amount,
        services: formData.selectedServices,
        products: formData.selectedProducts,
      };

      if (selectedBill) {
        await updateBill(selectedBill.id, billToSubmit);
      } else {
        await createBill(billToSubmit);
      }
      setIsModalOpen(false);
      setSelectedBill(null);
      setFormData({
        customer_id: '',
        staff_id: '',
        payment_mode: 'Offline',
        selectedServices: [],
        selectedProducts: [],
        total_amount: 0,
      });
      fetchData();
    } catch (error) {
      console.error('Error saving bill:', error);
    }
  };

  const handleEdit = (bill) => {
    setSelectedBill(bill);
    setFormData({
      customer_id: bill.customer_id,
      staff_id: bill.staff_id,
      payment_mode: bill.payment_mode,
      selectedServices: bill.bill_services.map(bs => ({ id: bs.service_id, quantity: bs.quantity, cost: bs.services.cost })),
      selectedProducts: bill.bill_products.map(bp => ({ id: bp.product_id, quantity: bp.quantity, cost_price: bp.products.cost_price })),
      total_amount: bill.total_amount,
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (billId) => {
    if (window.confirm('Are you sure you want to delete this bill?')) {
      try {
        await deleteBill(billId);
        fetchData();
      } catch (error) {
        console.error('Error deleting bill:', error);
      }
    }
  };

  const openModal = () => {
    setSelectedBill(null);
    setFormData({
      customer_id: '',
      staff_id: '',
      payment_mode: 'Offline',
      selectedServices: [],
      selectedProducts: [],
      total_amount: 0,
    });
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedBill(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <h1 className="text-4xl font-extrabold text-primary-accent mb-6 text-center">Manage Bills</h1>
      <button onClick={openModal} className="bg-primary-accent hover:bg-primary-dark text-white px-5 py-2 rounded-lg shadow-md mb-6 transition duration-300 ease-in-out">
        Create New Bill
      </button>

      {isModalOpen && (
        <div className="fixed inset-0 bg-background-dark bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-background-light p-6 rounded-xl shadow-2xl w-full max-w-3xl max-h-[80vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6 text-primary-accent text-center">{selectedBill ? 'Edit Bill' : 'Create Bill'}</h2>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-text-secondary text-sm font-semibold mb-2">Customer</label>
                <select
                  name="customer_id"
                  value={formData.customer_id}
                  onChange={handleInputChange}
                  className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
                  required
                >
                  <option value="">Select Customer</option>
                  {customers.map(customer => (
                    <option key={customer.id} value={customer.id}>{customer.name} ({customer.phone_number})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-text-secondary text-sm font-semibold mb-2">Staff</label>
                <select
                  name="staff_id"
                  value={formData.staff_id}
                  onChange={handleInputChange}
                  className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
                  required
                >
                  <option value="">Select Staff</option>
                  {staff.map(s => (
                    <option key={s.id} value={s.id}>{s.full_name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-text-secondary text-sm font-semibold mb-2">Payment Mode</label>
                <select
                  name="payment_mode"
                  value={formData.payment_mode}
                  onChange={handleInputChange}
                  className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
                >
                  <option value="Offline">Offline</option>
                  <option value="Online">Online</option>
                </select>
              </div>

              <div>
                <label className="block text-text-secondary text-sm font-semibold mb-2">Services</label>
                <div className="space-y-2">
                  {services.map(service => (
                    <div key={service.id} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.selectedServices.some(s => s.id === service.id)}
                        onChange={(e) => handleServiceChange(service.id, e.target.checked ? 1 : 0)}
                        className="form-checkbox h-5 w-5 text-primary-accent rounded focus:ring-primary-accent"
                      />
                      <span className="ml-3 text-text-primary">{service.name} - ${service.cost}</span>
                      {formData.selectedServices.some(s => s.id === service.id) && (
                        <input
                          type="number"
                          min="1"
                          value={formData.selectedServices.find(s => s.id === service.id)?.quantity || 1}
                          onChange={(e) => handleServiceChange(service.id, e.target.value)}
                          className="ml-4 p-2 border border-border-light rounded-lg w-24 text-center focus:outline-none focus:ring-2 focus:ring-primary-accent text-text-primary bg-background-light"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-text-secondary text-sm font-semibold mb-2">Products Sold</label>
                <div className="space-y-2">
                  {products.filter(p => p.type === 'for_sale').map(product => (
                    <div key={product.id} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.selectedProducts.some(p => p.id === product.id)}
                        onChange={(e) => handleProductChange(product.id, e.target.checked ? 1 : 0)}
                        className="form-checkbox h-5 w-5 text-primary-accent rounded focus:ring-primary-accent"
                      />
                      <span className="ml-3 text-text-primary">{product.name} (Stock: {product.quantity}) - ${product.cost_price}</span>
                      {formData.selectedProducts.some(p => p.id === product.id) && (
                        <input
                          type="number"
                          min="1"
                          max={product.quantity} // Max quantity is available stock
                          value={formData.selectedProducts.find(p => p.id === product.id)?.quantity || 1}
                          onChange={(e) => handleProductChange(product.id, e.target.value)}
                          className="ml-4 p-2 border border-border-light rounded-lg w-24 text-center focus:outline-none focus:ring-2 focus:ring-primary-accent text-text-primary bg-background-light"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-xl font-bold text-primary-accent mt-6">
                Total Amount: <span className="text-primary-dark">${formData.total_amount.toFixed(2)}</span>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button type="button" onClick={closeModal} className="bg-secondary-light hover:bg-secondary-dark text-text-secondary px-5 py-2 rounded-lg shadow-md transition duration-300 ease-in-out">
                  Cancel
                </button>
                <button type="submit" className="bg-primary-accent hover:bg-primary-dark text-white px-5 py-2 rounded-lg shadow-md transition duration-300 ease-in-out">
                  {selectedBill ? 'Update Bill' : 'Create Bill'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="overflow-x-auto bg-background-light rounded-lg shadow-2xl p-4">
        <table className="min-w-full divide-y divide-border-light">
          <thead className="bg-primary-light">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Bill ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Customer</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Staff</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Date</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Total</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Payment Mode</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Services</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Products</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-background-light divide-y divide-border-light">
            {bills.map(bill => (
              <tr key={bill.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">{bill.id.substring(0, 8)}...</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">{bill.customers?.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">{bill.profiles?.full_name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">{new Date(bill.bill_date).toLocaleDateString()}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">${bill.total_amount.toFixed(2)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">{bill.payment_mode}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                  {bill.bill_services.map(bs => (
                    <div key={bs.service_id}>{bs.services?.name} (x{bs.quantity})</div>
                  ))}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                  {bill.bill_products.map(bp => (
                    <div key={bp.product_id}>{bp.products?.name} (x{bp.quantity})</div>
                  ))}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => handleEdit(bill)} className="text-accent-yellow hover:text-yellow-600 mr-4">Edit</button>
                  <button onClick={() => handleDelete(bill.id)} className="text-red-600 hover:text-red-700">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageBills;