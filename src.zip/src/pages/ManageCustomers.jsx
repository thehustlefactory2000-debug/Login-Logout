import React, { useState, useEffect } from 'react';
import { getCustomers, addCustomer, updateCustomer, deleteCustomer } from '../lib/customerApi';

const ManageCustomers = () => {
  const [customers, setCustomers] = useState([]);
  const [newCustomer, setNewCustomer] = useState({ name: '', phone_number: '' });
  const [editingCustomer, setEditingCustomer] = useState(null);

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const data = await getCustomers();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error.message);
    }
  };

  const handleAddCustomer = async (e) => {
    e.preventDefault();
    try {
      await addCustomer(newCustomer);
      setNewCustomer({ name: '', phone_number: '' });
      fetchCustomers();
    } catch (error) {
      console.error('Error adding customer:', error.message);
    }
  };

  const handleEditCustomer = (customer) => {
    setEditingCustomer(customer);
    setNewCustomer({ name: customer.name, phone_number: customer.phone_number });
  };

  const handleUpdateCustomer = async (e) => {
    e.preventDefault();
    try {
      await updateCustomer(editingCustomer.id, newCustomer);
      setEditingCustomer(null);
      setNewCustomer({ name: '', phone_number: '' });
      fetchCustomers();
    } catch (error) {
      console.error('Error updating customer:', error.message);
    }
  };

  const handleDeleteCustomer = async (id) => {
    try {
      await deleteCustomer(id);
      fetchCustomers();
    } catch (error) {
      console.error('Error deleting customer:', error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <h1 className="text-4xl font-extrabold text-primary-accent mb-6 text-center">Manage Customers</h1>

      <form onSubmit={editingCustomer ? handleUpdateCustomer : handleAddCustomer} className="max-w-lg mx-auto mb-8 p-6 bg-background-light rounded-xl shadow-2xl">
        <h2 className="text-2xl font-bold text-primary-accent mb-5 text-center">{editingCustomer ? 'Edit Customer' : 'Add New Customer'}</h2>
        <div className="mb-4">
          <label htmlFor="customerName" className="block text-sm font-medium text-text-secondary mb-2">Customer Name</label>
          <input
            type="text"
            id="customerName"
            className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
            value={newCustomer.name}
            onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
            required
          />
        </div>
        <div className="mb-6">
          <label htmlFor="customerPhone" className="block text-sm font-medium text-text-secondary mb-2">Phone Number</label>
          <input
            type="text"
            id="customerPhone"
            className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
            value={newCustomer.phone_number}
            onChange={(e) => setNewCustomer({ ...newCustomer, phone_number: e.target.value })}
            required
          />
        </div>
        <div className="flex justify-center space-x-4">
          <button
            type="submit"
            className="px-6 py-3 bg-primary-accent text-white font-semibold rounded-lg shadow-md hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary-accent focus:ring-offset-2 transition duration-300 ease-in-out"
          >
            {editingCustomer ? 'Update Customer' : 'Add Customer'}
          </button>
          {editingCustomer && (
            <button
              type="button"
              onClick={() => {
                setEditingCustomer(null);
                setNewCustomer({ name: '', phone_number: '' });
              }}
              className="px-6 py-3 bg-secondary-light text-text-secondary font-semibold rounded-lg shadow-md hover:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-secondary-dark focus:ring-offset-2 transition duration-300 ease-in-out"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <h2 className="text-3xl font-extrabold text-primary-accent mb-5 text-center">Current Customers</h2>
      {customers.length === 0 ? (
        <p className="text-center text-text-secondary">No customers added yet.</p>
      ) : (
        <ul className="max-w-lg mx-auto bg-background-light shadow-2xl rounded-xl overflow-hidden">
          {customers.map((customer) => (
            <li key={customer.id} className="border-b border-border-light last:border-b-0">
              <div className="flex items-center justify-between p-5 hover:bg-background-hover transition duration-150 ease-in-out">
                <div>
                  <p className="text-xl font-medium text-primary-dark">{customer.name}</p>
                  <p className="text-md text-text-secondary">Phone: <span className="font-semibold">{customer.phone_number}</span></p>
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={() => handleEditCustomer(customer)}
                    className="px-4 py-2 text-sm bg-accent-yellow text-white rounded-lg shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-accent-yellow focus:ring-offset-2 transition duration-300 ease-in-out"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteCustomer(customer.id)}
                    className="px-4 py-2 text-sm bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition duration-300 ease-in-out"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ManageCustomers;