import React, { useState, useEffect } from 'react';
import { getProducts, addProduct, updateProduct, deleteProduct } from '../lib/productApi';

const ManageInventory = () => {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: '', quantity: '', purchase_date: '', cost_price: '', type: 'for_sale' });
  const [editingProduct, setEditingProduct] = useState(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const data = await getProducts();
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error.message);
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      await addProduct(newProduct);
      setNewProduct({ name: '', quantity: '', purchase_date: '', cost_price: '', type: 'for_sale' });
      fetchProducts();
    } catch (error) {
      console.error('Error adding product:', error.message);
    }
  };

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setNewProduct({ name: product.name, quantity: product.quantity, purchase_date: product.purchase_date, cost_price: product.cost_price, type: product.type });
  };

  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      await updateProduct(editingProduct.id, newProduct);
      setEditingProduct(null);
      setNewProduct({ name: '', quantity: '', purchase_date: '', cost_price: '', type: 'for_sale' });
      fetchProducts();
    } catch (error) {
      console.error('Error updating product:', error.message);
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      await deleteProduct(id);
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <h1 className="text-4xl font-extrabold text-primary-accent mb-6 text-center">Manage Inventory</h1>

      <form onSubmit={editingProduct ? handleUpdateProduct : handleAddProduct} className="max-w-2xl mx-auto mb-8 p-6 bg-background-light rounded-xl shadow-2xl">
        <h2 className="text-2xl font-bold text-primary-accent mb-5 text-center">{editingProduct ? 'Edit Product' : 'Add New Product'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="productName" className="block text-sm font-medium text-text-secondary mb-2">Product Name</label>
            <input
              type="text"
              id="productName"
              className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              required
            />
          </div>
          <div>
            <label htmlFor="productQuantity" className="block text-sm font-medium text-text-secondary mb-2">Quantity</label>
            <input
              type="number"
              id="productQuantity"
              className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
              value={newProduct.quantity}
              onChange={(e) => setNewProduct({ ...newProduct, quantity: parseFloat(e.target.value) })}
              required
            />
          </div>
          <div>
            <label htmlFor="productPurchaseDate" className="block text-sm font-medium text-text-secondary mb-2">Purchase Date</label>
            <input
              type="date"
              id="productPurchaseDate"
              className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
              value={newProduct.purchase_date}
              onChange={(e) => setNewProduct({ ...newProduct, purchase_date: e.target.value })}
            />
          </div>
          <div>
            <label htmlFor="productCostPrice" className="block text-sm font-medium text-text-secondary mb-2">Cost Price</label>
            <input
              type="number"
              id="productCostPrice"
              className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
              value={newProduct.cost_price}
              onChange={(e) => setNewProduct({ ...newProduct, cost_price: parseFloat(e.target.value) })}
            />
          </div>
        </div>
        <div className="mb-6">
          <label htmlFor="productType" className="block text-sm font-medium text-text-secondary mb-2">Product Type</label>
          <select
            id="productType"
            className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
            value={newProduct.type}
            onChange={(e) => setNewProduct({ ...newProduct, type: e.target.value })}
            required
          >
            <option value="for_sale">For Sale</option>
            <option value="for_service_use">For Service Use</option>
          </select>
        </div>
        <div className="flex justify-center space-x-4">
          <button
            type="submit"
            className="px-6 py-3 bg-primary-accent text-white font-semibold rounded-lg shadow-md hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary-accent focus:ring-offset-2 transition duration-300 ease-in-out"
          >
            {editingProduct ? 'Update Product' : 'Add Product'}
          </button>
          {editingProduct && (
            <button
              type="button"
              onClick={() => {
                setEditingProduct(null);
                setNewProduct({ name: '', quantity: '', purchase_date: '', cost_price: '', type: 'for_sale' });
              }}
              className="px-6 py-3 bg-secondary-light text-text-secondary font-semibold rounded-lg shadow-md hover:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-secondary-dark focus:ring-offset-2 transition duration-300 ease-in-out"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <h2 className="text-3xl font-extrabold text-primary-accent mb-5 text-center">Current Inventory</h2>
      {products.length === 0 ? (
        <p className="text-center text-text-secondary">No products in inventory yet.</p>
      ) : (
        <ul className="max-w-2xl mx-auto bg-background-light shadow-2xl rounded-xl overflow-hidden">
          {products.map((product) => (
            <li key={product.id} className="border-b border-border-light last:border-b-0">
              <div className="flex items-center justify-between p-5 hover:bg-background-hover transition duration-150 ease-in-out">
                <div>
                  <p className="text-xl font-medium text-primary-dark">{product.name} <span className="text-sm text-text-secondary">({product.type === 'for_sale' ? 'For Sale' : 'For Service Use'})</span></p>
                  <p className="text-md text-text-secondary">Quantity: <span className="font-semibold">{product.quantity}</span></p>
                  {product.cost_price && <p className="text-md text-text-secondary">Cost Price: <span className="font-semibold">${product.cost_price}</span></p>}
                  {product.purchase_date && <p className="text-md text-text-secondary">Purchase Date: <span className="font-semibold">{product.purchase_date}</span></p>}
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={() => handleEditProduct(product)}
                    className="px-4 py-2 text-sm bg-accent-yellow text-white rounded-lg shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-accent-yellow focus:ring-offset-2 transition duration-300 ease-in-out"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    className="px-4 py-2 text-sm bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition duration-300 ease-in-out"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ManageInventory;