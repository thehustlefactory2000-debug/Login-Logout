import React, { useState, useEffect } from 'react';
import { getServices, addService, updateService, deleteService } from '../lib/serviceApi';

const ManageServices = () => {
  const [services, setServices] = useState([]);
  const [newService, setNewService] = useState({ name: '', cost: '' });
  const [editingService, setEditingService] = useState(null);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const data = await getServices();
      setServices(data);
    } catch (error) {
      console.error('Error fetching services:', error.message);
    }
  };

  const handleAddService = async (e) => {
    e.preventDefault();
    try {
      await addService(newService);
      setNewService({ name: '', cost: '' });
      fetchServices();
    } catch (error) {
      console.error('Error adding service:', error.message);
    }
  };

  const handleEditService = (service) => {
    setEditingService(service);
    setNewService({ name: service.name, cost: service.cost });
  };

  const handleUpdateService = async (e) => {
    e.preventDefault();
    try {
      await updateService(editingService.id, newService);
      setEditingService(null);
      setNewService({ name: '', cost: '' });
      fetchServices();
    } catch (error) {
      console.error('Error updating service:', error.message);
    }
  };

  const handleDeleteService = async (id) => {
    try {
      await deleteService(id);
      fetchServices();
    } catch (error) {
      console.error('Error deleting service:', error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <h1 className="text-4xl font-extrabold text-primary-accent mb-6 text-center">Manage Services</h1>

      <form onSubmit={editingService ? handleUpdateService : handleAddService} className="max-w-lg mx-auto mb-8 p-6 bg-background-light rounded-xl shadow-2xl">
        <h2 className="text-2xl font-bold text-primary-accent mb-5 text-center">{editingService ? 'Edit Service' : 'Add New Service'}</h2>
        <div className="mb-4">
          <label htmlFor="serviceName" className="block text-sm font-medium text-text-secondary mb-2">Service Name</label>
          <input
            type="text"
            id="serviceName"
            className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
            value={newService.name}
            onChange={(e) => setNewService({ ...newService, name: e.target.value })}
            required
          />
        </div>
        <div className="mb-6">
          <label htmlFor="serviceCost" className="block text-sm font-medium text-text-secondary mb-2">Cost</label>
          <input
            type="number"
            id="serviceCost"
            className="mt-1 block w-full p-3 border border-border-light rounded-lg shadow-sm focus:ring-primary-accent focus:border-primary-accent text-text-primary bg-background-light"
            value={newService.cost}
            onChange={(e) => setNewService({ ...newService, cost: parseFloat(e.target.value) })}
            required
          />
        </div>
        <button
          type="submit"
          className="w-full px-4 py-3 bg-primary-accent text-white font-semibold rounded-lg shadow-md hover:bg-primary-dark transition duration-300 focus:outline-none focus:ring-2 focus:ring-primary-accent focus:ring-offset-2"
        >
          {editingService ? 'Update Service' : 'Add Service'}
        </button>
        {editingService && (
          <button
            type="button"
            onClick={() => {
              setEditingService(null);
              setNewService({ name: '', cost: '' });
            }}
            className="w-full mt-3 px-4 py-3 bg-secondary-light text-text-secondary font-semibold rounded-lg shadow-md hover:bg-secondary-dark transition duration-300 focus:outline-none focus:ring-2 focus:ring-secondary-dark focus:ring-offset-2"
          >
            Cancel
          </button>
        )}
      </form>

      <h2 className="text-3xl font-extrabold text-primary-accent mb-5 text-center">Current Services</h2>
      {services.length === 0 ? (
        <p className="text-center text-text-secondary">No services added yet.</p>
      ) : (
        <ul className="max-w-lg mx-auto bg-background-light shadow-2xl rounded-xl overflow-hidden">
          {services.map((service) => (
            <li key={service.id} className="border-b border-border-light last:border-b-0">
              <div className="flex items-center justify-between p-5">
                <div>
                  <p className="text-xl font-medium text-primary-dark">{service.name}</p>
                  <p className="text-md text-text-secondary">Cost: <span className="font-semibold">${service.cost}</span></p>
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={() => handleEditService(service)}
                    className="px-4 py-2 text-sm bg-accent-yellow text-white rounded-lg shadow-md hover:bg-yellow-600 transition duration-300 focus:outline-none focus:ring-2 focus:ring-accent-yellow focus:ring-offset-2"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteService(service.id)}
                    className="px-4 py-2 text-sm bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 transition duration-300 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ManageServices;