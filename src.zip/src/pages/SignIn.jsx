import React, { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useNavigate, Link } from "react-router-dom";

const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSignIn = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const { data: { user }, error: authError } =
        await supabase.auth.signInWithPassword({ email, password });

      if (authError) throw authError;
      if (!user) throw new Error("No user returned.");

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();

      if (profile?.role === "admin") navigate("/admin");
      else if (profile?.role === "staff") navigate("/staff");
      else navigate("/user");

    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 py-6">

      {/* CARD */}
      <div className="w-full max-w-sm bg-white p-6 sm:p-7 rounded-2xl shadow-lg">

        {/* TITLE */}
        <h2 className="text-xl sm:text-2xl font-semibold text-gray-800 text-center mb-6">
          Sign In
        </h2>

        {/* FORM */}
        <form onSubmit={handleSignIn} className="space-y-5">

          {/* ERROR */}
          {error && (
            <div className="text-red-600 bg-red-100 border border-red-200 p-3 rounded-lg text-sm text-center">
              {error}
            </div>
          )}

          {/* EMAIL */}
          <div className="flex flex-col items-center">
            <label className="block text-gray-600 text-sm mb-1 w-full sm:max-w-xs mx-auto">
              Email
            </label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="
                w-full sm:max-w-xs mx-auto
                p-3 border border-gray-300 rounded-lg 
                focus:ring-2 focus:ring-gray-700 outline-none bg-white
              "
              required
            />
          </div>

          {/* PASSWORD */}
          <div className="flex flex-col items-center">
            <label className="block text-gray-600 text-sm mb-1 w-full sm:max-w-xs mx-auto">
              Password
            </label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="
                w-full sm:max-w-xs mx-auto
                p-3 border border-gray-300 rounded-lg 
                focus:ring-2 focus:ring-gray-700 outline-none bg-white
              "
              required
            />
          </div>

          {/* BUTTON */}
          <button
            type="submit"
            disabled={loading}
            className="
              w-full sm:max-w-xs mx-auto block
              bg-gray-800 text-white p-3 rounded-lg 
              hover:bg-black transition-colors
            "
          >
            {loading ? "Signing In..." : "Sign In"}
          </button>

        </form>

        {/* FOOTER */}
        <p className="text-center text-sm text-gray-500 mt-4">
          Don't have an account?{" "}
          <Link className="text-gray-800 font-semibold hover:underline" to="/signup">
            Sign Up
          </Link>
        </p>

      </div>
    </div>
  );
};

export default SignIn;
