import React, { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useNavigate, Link } from 'react-router-dom';


const SignUp = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSignUp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match!');
      setLoading(false);
      return;
    }

    // Basic password validation
    if (password.length < 6) {
      setError('Password must be at least 6 characters long');
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        throw error;
      }

      // Check if email confirmation is required
      if (data?.user?.identities?.length === 0) {
        setError('This email is already registered. Please sign in instead.');
        setLoading(false);
        return;
      }

      // Insert user role into profiles table
      await supabase.from('profiles').insert({
        user_id: data.user.id,
        role: 'user', // Default role
      });

      // Success message
      alert('Check your email for the confirmation link!');

      // Redirect to sign-in page
      navigate('/signin');
    } catch (error) {
      console.error('Sign up error:', error);
      setError(error.message || 'An error occurred during sign up');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary">
      <div className="bg-background-light p-8 rounded-xl shadow-2xl w-full max-w-md">
        <h2 className="text-3xl font-extrabold text-primary-accent mb-6 text-center">Sign Up</h2>
        <form onSubmit={handleSignUp} className="space-y-4">
          {error && <p className="text-red-500 text-sm mb-4 text-center">{error}</p>}
          <div>
            <label htmlFor="email" className="block text-text-secondary text-sm font-semibold mb-2">Email:</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-text-secondary text-sm font-semibold mb-2">Password:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
            />
          </div>
          <div>
            <label htmlFor="confirm-password" className="block text-text-secondary text-sm font-semibold mb-2">Confirm Password:</label>
            <input
              type="password"
              id="confirm-password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              className="block w-full p-3 border border-border-light rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-accent transition duration-200 text-text-primary bg-background-light"
            />
          </div>
          <button type="submit" disabled={loading} className="bg-primary-accent hover:bg-primary-dark text-white px-5 py-2 rounded-lg shadow-md transition duration-300 ease-in-out w-full">
            {loading ? 'Signing Up...' : 'Sign Up'}
          </button>
        </form>
        <p className="text-center text-sm text-text-secondary mt-4">
          Already have an account? <Link to="/signin" className="text-primary-accent hover:text-primary-dark">Sign In</Link>
        </p>
      </div>
    </div>
  );
};

export default SignUp;