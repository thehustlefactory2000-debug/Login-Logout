import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';


const StaffDashboard = () => {
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/signin'); // Redirect to login if not authenticated
      }
      setLoading(false);
    };

    checkAuth();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/signin');
  };

  if (loading) {
    return <div className="auth-container">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-primary-dark p-4 sm:p-6 lg:p-8 font-sans text-text-primary flex items-center justify-center">
      <div className="bg-background-light p-8 rounded-xl shadow-2xl w-full max-w-md text-center">
        <h2 className="text-3xl font-extrabold text-primary-accent mb-6">Staff Dashboard</h2>
        <p className="text-text-secondary mb-8">Welcome to the Staff Dashboard!</p>
        {/* Add staff-specific content here */}
        <button
          onClick={handleLogout}
          className="w-full bg-primary-accent hover:bg-primary-dark text-white font-semibold py-2 px-4 rounded-lg shadow-md transition duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-accent focus:ring-offset-2"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default StaffDashboard;